import Foundation
import shared
import Combine

class ApplicationsViewModel: ObservableObject {
    @Published var applications: [Application] = []
    
    private var cancellables = Set<AnyCancellable>()
    private let viewModel: shared.ApplicationsViewModel
    
    init() {
        viewModel = KoinHelper.shared.getApplicationsViewModel()
        
        viewModel.uiState.asPublisher()
            .map { state in
                state.applications
            }
            .receive(on: DispatchQueue.main)
            .assign(to: \.applications, on: self)
            .store(in: &cancellables)
    }
}

class ApplicationDetailViewModel: ObservableObject {
    @Published var application: Application?
    @Published var tasks: [Task] = []
    @Published var interviews: [Interview] = []
    
    private var cancellables = Set<AnyCancellable>()
    private let viewModel: shared.ApplicationDetailViewModel
    
    init() {
        viewModel = KoinHelper.shared.getApplicationDetailViewModel()
        
        viewModel.uiState.asPublisher()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] state in
                self?.application = state.application
                self?.tasks = state.tasks
                self?.interviews = state.interviews
            }
            .store(in: &cancellables)
    }
    
    func loadApplication(applicationId: String) {
        viewModel.loadApplication(applicationId: applicationId)
    }
}

class SettingsViewModel: ObservableObject {
    @Published var lastSyncedAtEpochMs: Int64?
    @Published var isSyncing: Bool = false
    @Published var syncError: String?
    
    private var cancellables = Set<AnyCancellable>()
    private let viewModel: shared.SettingsViewModel
    
    init() {
        viewModel = KoinHelper.shared.getSettingsViewModel()
        
        viewModel.uiState.asPublisher()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] state in
                self?.lastSyncedAtEpochMs = state.lastSyncedAtEpochMs as? Int64
                self?.isSyncing = state.isSyncing
                self?.syncError = state.syncError
            }
            .store(in: &cancellables)
    }
    
    func syncNow(userId: String) {
        viewModel.syncNow(userId: userId)
    }
}

extension Kotlinx_coroutines_coreFlow {
    func asPublisher() -> AnyPublisher<Element, Never> {
        return FlowPublisher(flow: self).eraseToAnyPublisher()
    }
}

class FlowPublisher<T: AnyObject>: Publisher {
    typealias Output = T
    typealias Failure = Never
    
    private let flow: Kotlinx_coroutines_coreFlow
    
    init(flow: Kotlinx_coroutines_coreFlow) {
        self.flow = flow
    }
    
    func receive<S>(subscriber: S) where S : Subscriber, Never == S.Failure, T == S.Input {
        let subscription = FlowSubscription(flow: flow, subscriber: subscriber)
        subscriber.receive(subscription: subscription)
    }
}

class FlowSubscription<S: Subscriber>: Subscription where S.Input: AnyObject {
    private let flow: Kotlinx_coroutines_coreFlow
    private let subscriber: S
    private var job: Kotlinx_coroutines_coreJob?
    
    init(flow: Kotlinx_coroutines_coreFlow, subscriber: S) {
        self.flow = flow
        self.subscriber = subscriber
    }
    
    func request(_ demand: Subscribers.Demand) {
        job = CoroutinesKt.asFlow(flow) { [weak self] value in
            _ = self?.subscriber.receive(value as! S.Input)
        }
    }
    
    func cancel() {
        job?.cancel(cause: nil)
    }
}

