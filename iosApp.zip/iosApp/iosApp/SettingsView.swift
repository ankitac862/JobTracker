import SwiftUI
import shared

struct SettingsView: View {
    @StateObject private var viewModel = SettingsViewModel()
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var showPassword: Bool = false
    
    var body: some View {
        NavigationView {
            Form {
                // Authentication Section
                Section(header: Text("Authentication")) {
                    if viewModel.isSignedIn {
                        // Signed In State
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Signed in as:")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Text(viewModel.currentUserId ?? "Unknown")
                                .font(.body)
                                .fontWeight(.medium)
                        }
                        .padding(.vertical, 4)
                        
                        Button(action: {
                            viewModel.signOut()
                        }) {
                            HStack {
                                Image(systemName: "rectangle.portrait.and.arrow.right")
                                Text("Sign Out")
                            }
                            .foregroundColor(.red)
                        }
                    } else {
                        // Sign In/Up State
                        VStack(spacing: 12) {
                            TextField("Email", text: $email)
                                .textContentType(.emailAddress)
                                .autocapitalization(.none)
                                .keyboardType(.emailAddress)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                            
                            HStack {
                                if showPassword {
                                    TextField("Password", text: $password)
                                        .textFieldStyle(RoundedBorderTextFieldStyle())
                                } else {
                                    SecureField("Password", text: $password)
                                        .textFieldStyle(RoundedBorderTextFieldStyle())
                                }
                                
                                Button(action: {
                                    showPassword.toggle()
                                }) {
                                    Image(systemName: showPassword ? "eye.slash" : "eye")
                                        .foregroundColor(.secondary)
                                }
                            }
                            
                            HStack(spacing: 12) {
                                Button(action: {
                                    viewModel.signIn(email: email, password: password)
                                }) {
                                    if viewModel.isAuthLoading {
                                        ProgressView()
                                            .progressViewStyle(CircularProgressViewStyle())
                                    } else {
                                        Text("Sign In")
                                            .fontWeight(.semibold)
                                    }
                                }
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                                .disabled(viewModel.isAuthLoading || email.isEmpty || password.isEmpty)
                                
                                Button(action: {
                                    viewModel.signUp(email: email, password: password)
                                }) {
                                    Text("Sign Up")
                                        .fontWeight(.semibold)
                                }
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.secondary.opacity(0.2))
                                .foregroundColor(.primary)
                                .cornerRadius(8)
                                .disabled(viewModel.isAuthLoading || email.isEmpty || password.isEmpty)
                            }
                            
                            if let authError = viewModel.authError {
                                Text(authError)
                                    .font(.caption)
                                    .foregroundColor(.red)
                                    .multilineTextAlignment(.center)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
                
                // Sync Section (only show when signed in)
                if viewModel.isSignedIn {
                    Section(header: Text("Cloud Sync")) {
                        VStack(alignment: .leading, spacing: 8) {
                            if let lastSynced = viewModel.lastSyncedAtEpochMs {
                                HStack {
                                    Text("Last synced:")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                    Spacer()
                                    Text(formatDate(epochMs: lastSynced))
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            } else {
                                Text("Not synced yet")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                        .padding(.vertical, 4)
                        
                        Button(action: {
                            if let userId = viewModel.currentUserId {
                                viewModel.syncNow(userId: userId)
                            }
                        }) {
                            HStack {
                                if viewModel.isSyncing {
                                    ProgressView()
                                        .progressViewStyle(CircularProgressViewStyle())
                                    Text("Syncing...")
                                        .padding(.leading, 8)
                                } else {
                                    Image(systemName: "arrow.triangle.2.circlepath")
                                    Text("Sync Now")
                                        .padding(.leading, 8)
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                        }
                        .disabled(viewModel.isSyncing)
                        
                        if let syncError = viewModel.syncError {
                            Text("Error: \(syncError)")
                                .font(.caption)
                                .foregroundColor(.red)
                        }
                    }
                }
                
                // App Information Section
                Section(header: Text("About")) {
                    HStack {
                        Text("Version")
                        Spacer()
                        Text("1.0.0")
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Build")
                        Spacer()
                        Text("1")
                            .foregroundColor(.secondary)
                    }
                }
            }
            .navigationTitle("Settings")
        }
    }
    
    private func formatDate(epochMs: Int64) -> String {
        let date = Date(timeIntervalSince1970: TimeInterval(epochMs / 1000))
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

#if DEBUG
struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}
#endif
