import SwiftUI
import shared

struct AddEditApplicationView: View {
    @State private var companyName = ""
    @State private var positionTitle = ""
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Application Details")) {
                    TextField("Company Name", text: $companyName)
                    TextField("Position Title", text: $positionTitle)
                }
            }
            .navigationTitle("Add Application")
            .navigationBarItems(
                leading: Button("Cancel") {
                    presentationMode.wrappedValue.dismiss()
                },
                trailing: Button("Save") {
                    presentationMode.wrappedValue.dismiss()
                }
            )
        }
    }
}

