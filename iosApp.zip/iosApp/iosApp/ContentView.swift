import SwiftUI
import shared

struct ContentView: View {
    @StateObject private var viewModel = ApplicationsViewModel()
    
    var body: some View {
        NavigationView {
            ApplicationsListView(viewModel: viewModel)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

