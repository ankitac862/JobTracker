import Foundation
import shared
import Combine

class SettingsViewModel: ObservableObject {
    @Published var isSignedIn: Bool = false
    @Published var currentUserId: String? = nil
    @Published var isAuthLoading: Bool = false
    @Published var authError: String? = nil
    
    @Published var isSyncing: Bool = false
    @Published var lastSyncedAtEpochMs: Int64? = nil
    @Published var syncError: String? = nil
    
    private var cancellables = Set<AnyCancellable>()
    private let authWrapper: FirebaseAuthWrapper
    private let syncCoordinator: SyncCoordinator
    
    init() {
        // Get instances from Koin DI
        let koinApplication = KoinHelperKt.koin
        self.authWrapper = koinApplication.get(objCClass: FirebaseAuthWrapper.self) as! FirebaseAuthWrapper
        self.syncCoordinator = koinApplication.get(objCClass: SyncCoordinator.self) as! SyncCoordinator
        
        // Observe auth state
        observeAuthState()
        
        // Observe sync state
        observeSyncState()
    }
    
    private func observeAuthState() {
        // Convert Kotlin Flow to Combine Publisher
        Task {
            for await userId in authWrapper.observeAuthState() {
                DispatchQueue.main.async {
                    self.currentUserId = userId as? String
                    self.isSignedIn = userId != nil
                }
            }
        }
    }
    
    private func observeSyncState() {
        // Convert Kotlin Flow to Combine Publisher
        Task {
            for await state in syncCoordinator.syncState {
                if let syncState = state as? SyncState {
                    DispatchQueue.main.async {
                        self.isSyncing = syncState.isSyncing
                        self.lastSyncedAtEpochMs = syncState.lastSyncedAtEpochMs?.int64Value
                        
                        if let error = syncState.syncError {
                            self.syncError = error.localizedDescription
                        } else {
                            self.syncError = nil
                        }
                    }
                }
            }
        }
    }
    
    func signIn(email: String, password: String) {
        isAuthLoading = true
        authError = nil
        
        Task {
            do {
                let result = try await authWrapper.signInWithEmail(email: email, password: password)
                
                DispatchQueue.main.async {
                    self.isAuthLoading = false
                    
                    if result is ResultError {
                        let error = result as! ResultError
                        self.authError = error.exception.localizedDescription
                    } else if result is ResultSuccess {
                        // Success - auth state will update automatically
                        self.authError = nil
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    self.isAuthLoading = false
                    self.authError = error.localizedDescription
                }
            }
        }
    }
    
    func signUp(email: String, password: String) {
        isAuthLoading = true
        authError = nil
        
        Task {
            do {
                let result = try await authWrapper.signUpWithEmail(email: email, password: password)
                
                DispatchQueue.main.async {
                    self.isAuthLoading = false
                    
                    if result is ResultError {
                        let error = result as! ResultError
                        self.authError = error.exception.localizedDescription
                    } else if result is ResultSuccess {
                        // Success - auth state will update automatically
                        self.authError = nil
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    self.isAuthLoading = false
                    self.authError = error.localizedDescription
                }
            }
        }
    }
    
    func signOut() {
        Task {
            do {
                _ = try await authWrapper.signOut()
                
                DispatchQueue.main.async {
                    self.authError = nil
                }
            } catch {
                DispatchQueue.main.async {
                    self.authError = error.localizedDescription
                }
            }
        }
    }
    
    func syncNow(userId: String) {
        Task {
            do {
                try await syncCoordinator.syncNow(userId: userId)
            } catch {
                DispatchQueue.main.async {
                    self.syncError = error.localizedDescription
                }
            }
        }
    }
}

