import SwiftUI
import shared

struct ApplicationsListView: View {
    @ObservedObject var viewModel: ApplicationsViewModel
    
    var body: some View {
        List(viewModel.applications, id: \.applicationId) { application in
            NavigationLink(destination: ApplicationDetailView(applicationId: application.applicationId)) {
                ApplicationRow(application: application)
            }
        }
        .navigationTitle("Job Applications")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: {}) {
                    Image(systemName: "plus")
                }
            }
        }
    }
}

struct ApplicationRow: View {
    let application: Application
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(application.companyName)
                .font(.headline)
            Text(application.positionTitle)
                .font(.subheadline)
            Text(application.applicationStatus.name)
                .font(.caption)
        }
    }
}

