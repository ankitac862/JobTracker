import SwiftUI
import shared

struct ApplicationDetailView: View {
    let applicationId: String
    @StateObject private var viewModel = ApplicationDetailViewModel()
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                if let application = viewModel.application {
                    Text(application.companyName)
                        .font(.largeTitle)
                    Text(application.positionTitle)
                        .font(.title2)
                    
                    TasksSection(tasks: viewModel.tasks)
                    InterviewsSection(interviews: viewModel.interviews)
                } else {
                    ProgressView()
                }
            }
            .padding()
        }
        .navigationTitle("Details")
        .onAppear {
            viewModel.loadApplication(applicationId: applicationId)
        }
    }
}

struct TasksSection: View {
    let tasks: [Task]
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Tasks")
                .font(.headline)
            ForEach(tasks, id: \.taskId) { task in
                TaskRow(task: task)
            }
        }
    }
}

struct TaskRow: View {
    let task: Task
    
    var body: some View {
        HStack {
            Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
            VStack(alignment: .leading) {
                Text(task.title)
                if let description = task.description {
                    Text(description)
                        .font(.caption)
                }
            }
        }
    }
}

struct InterviewsSection: View {
    let interviews: [Interview]
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Interviews")
                .font(.headline)
            ForEach(interviews, id: \.interviewId) { interview in
                InterviewRow(interview: interview)
            }
        }
    }
}

struct InterviewRow: View {
    let interview: Interview
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(interview.interviewMode.name)
            if let interviewerName = interview.interviewerName {
                Text(interviewerName)
                    .font(.caption)
            }
        }
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(8)
    }
}

