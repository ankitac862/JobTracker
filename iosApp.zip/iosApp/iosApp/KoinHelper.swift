import Foundation
import shared

class KoinHelper {
    static let shared = KoinHelper()
    
    private init() {
        KoinKt.doInitKoin()
    }
    
    func getApplicationsViewModel() -> shared.ApplicationsViewModel {
        return KoinKt.getKoin().get()
    }
    
    func getApplicationDetailViewModel() -> shared.ApplicationDetailViewModel {
        return KoinKt.getKoin().get()
    }
    
    func getSettingsViewModel() -> shared.SettingsViewModel {
        return KoinKt.getKoin().get()
    }
}

